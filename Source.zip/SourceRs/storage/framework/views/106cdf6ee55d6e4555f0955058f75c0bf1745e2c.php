<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    Hello <?php echo e($demo->receiver); ?>,
This is a demo email for testing purposes! Also, it's the HTML version.

Demo object values:

Demo One: <?php echo e($demo->demo_one); ?>

Demo Two: <?php echo e($demo->demo_two); ?>


Values passed by With method:

testVarOne: <?php echo e($testVarOne); ?>

testVarOne: <?php echo e($testVarOne); ?>


Thank You,
<?php echo e($demo->sender); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\SourceRs\resources\views/aboat.blade.php ENDPATH**/ ?>